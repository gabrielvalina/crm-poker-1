from the_functions import *
import time

############
#COMPLEXITY#
############

ref_t1 = 0.
ref_t2 = 0.
ref_t3 = 0.
n = 1000

for i in range(0, n):

    start1 = time.time()
    h1 = hand(deck,[])
    h2 = hand(deck,h1)
    r1 = river_draw(deck,h1+h2)
    inter1 = time.time()

    start = time.time()
    winning_hand(h1, h2, r1)
    end = time.time()
    ref_t1 += (end-start)

    start = time.time()
    winning_hand_opt(h1, h2, r1)
    end = time.time()
    ref_t2 += (end - start)

    end1 = time.time()
    ref_t3 += (end1 - start1 + inter1 - start)

print(float(ref_t1)/float(ref_t2)) #Optimized function 1.75 times faster on average
print(float(ref_t3)/float(n)) #Average time for one party: 0.00045 sec with optimized function