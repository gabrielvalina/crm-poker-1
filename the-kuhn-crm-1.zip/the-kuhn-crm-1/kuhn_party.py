from paths import *
import pickle
import random
import copy

kuhn_deck = {"J": 0, "Q": 1, "K": 2}

strategy_list = pickle.load(open(path_the + "strategy_kuhn_cfr.txt", "rb"))
strategy = copy.deepcopy(strategy_list[len(strategy_list)-1])

check = 'check'
bet = 'bet'
call = 'call'
fold = 'fold'

all_hands = ['J', 'Q', 'K']


def fct_opponent_hand(hand):
    ref = copy.deepcopy(all_hands)
    ref.remove(hand)
    return random.choice(ref)


def fct_choose_action(actions, strategy):
    if strategy[actions[0]] > strategy[actions[1]]:
        return actions[0]
    elif strategy[actions[0]] < strategy[actions[1]]:
        return actions[1]
    else:
        return random.choice([actions[0], actions[1]])


total = 0


def kuhn_game_against_cfr(strtgy):
    my_card = random.choice(all_hands)
    opponent_card = fct_opponent_hand(my_card)
    opponent_strategy = strtgy[opponent_card]
    print('My card: ' + my_card)
    if kuhn_deck[my_card] > kuhn_deck[opponent_card]:
        res = 'YOU WON'
    else:
        res = 'YOU LOST'
    error_msg = 'wrong entry, please choose wisely'

    while True:
        try:
            choice = str(input("check or bet ? "))
            if choice == check:
                actions = copy.deepcopy([check, bet])
                opponent_choice = fct_choose_action(actions, opponent_strategy)
                if opponent_choice == check:
                    print('your opponent checks')
                    print('opponent card: ' + opponent_card)
                    print(res)
                else:
                    print('your opponent bets')
                    while True:
                        try:
                            choice = str(input("call or fold ? "))
                            if choice == call:
                                print('opponent card: ' + opponent_card)
                                print(res)
                            elif choice == fold:
                                print('YOU LOST')
                            break
                        except (ValueError, NameError, TypeError):
                            print(error_msg)
            elif choice == bet:
                actions = copy.deepcopy([call, fold])
                opponent_choice = fct_choose_action(actions, opponent_strategy)
                if opponent_choice == call:
                    print('your opponent calls')
                    print('opponent card: ' + opponent_card)
                    print(res)
                else:
                    print('your opponent folds')
                    print('YOU WON')
            break
        except (ValueError, NameError, TypeError):
            print(error_msg)


kuhn_game_against_cfr(strategy)
