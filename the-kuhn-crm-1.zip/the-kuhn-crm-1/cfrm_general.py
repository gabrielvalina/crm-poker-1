import random
import copy

kuhn_deck = {"J": 0, "Q": 1, "K": 2}

results = {}
for c1 in kuhn_deck.keys():
    for c2 in kuhn_deck.keys():
        if c1 != c2:
            results[c1 + c2] = (1 if kuhn_deck[c1] > kuhn_deck[c2] else -1)

all_actions = ['check', 'bet', 'call', 'fold']
all_hands = ['J', 'Q', 'K']


def fct_opponent_hand(hand):
    ref = copy.deepcopy(all_hands)
    ref.remove(hand)
    return random.choice(ref)


def fct_next_turn(arg):
    ref_list = ['a', 'b']
    ref_list.remove(arg)
    return ref_list[0]


def fct_remaining_hands(hand):
    res = copy.deepcopy(all_hands)
    res.remove(hand)
    return res


def define_actions(h, next_turn):
    L = len(h)
    if next_turn == 'chance' or L == 0:
        return ['check', 'bet']
    elif L == 1 and h[L-1] == 'check':
        return ['check', 'bet']
    elif h[L-1] == 'bet':
        return ['fold', 'call']


class InformationSet:
    def __init__(self, histo, private, public, proba, next_turn, actions):
        self.histo = histo  # list past actions common to all info sets
        self.private = private
        self.public = public  # list of public cards (= [] in case of Kuhn poker)
        self.proba = proba
        self.next_turn = next_turn  # 1, 2 or "chance", should be the same for each player
        self.actions = actions  # possible actions at this time of the party
        self.child = {}

    # function to determine which action to choose based on highest proba
    def _choose_action(self):  # actions determined by define_actions()
        # function to define which actions are possible based on last action
        if len(self.actions) > 0:
            ref = {action: self.proba[self.private][action] for action in self.actions}
            inv = {p: [] for p in ref.values()}
            for a in self.actions:
                inv[ref[a]].append(a)
            ref_max = max(inv.keys())
            return random.choice(inv[ref_max])
        else:
            return None


class Node:

    def __init__(self, information_set):
        self.information_set = information_set

    def _is_chance(self):
        return self.information_set.next_turn == 'chance'  # as next_turn common to both players

    def _is_terminal(self):
        histo = self.information_set.histo
        L = len(histo)
        if L > 1:
            # if last action is fold or if two past actions are the same
            # (2 successive bets or checks indicate terminal node)
            return (histo[L-1] == 'fold') or (histo[L-1] == 'call') \
                   or (histo[L-1] == 'check' and histo[L-2] == 'check')  # double check
        else:
            return False

    def _define_children(self):
        info_set = self.information_set
        if info_set.actions is not None:
            info_set.child = {action: None for action in info_set.actions}
            for action in info_set.actions:
                histo_child = copy.deepcopy(info_set.histo)
                histo_child.append(action)
                following_turn = fct_next_turn(info_set.next_turn)
                following_actions = define_actions(histo_child, following_turn)
                info_set.child[action] = InformationSet(histo_child, info_set.private,
                                                        info_set.public, info_set.proba,
                                                        following_turn,following_actions)

    def _init_dic(self):
        initial_dic = dict()
        initial_dic[self] = {action: 0. for action in all_actions}
        return initial_dic


class CounterfactualRegretMinimizationKuhn:  # to do for all cards for B

    def __init__(self, root_node):
        self.root_node = root_node
        self.opponent_hand = None
        self.cumulative_regret = {private_b: {act: 0. for act in all_actions}
                                  for private_b in fct_remaining_hands(root_node.information_set.private)}

    def _cumulative_regret(self, private_b, action, regret):
        self.cumulative_regret[private_b][action] += regret

    def _kuhn_crm_utility_recursive(self, node, p_a, p_b):
        # arguments = node, probability of player a reaching the
        # node and probability if player b reaching the node
        p_chance = 1./6  # for Kuhn poker
        info_set = node.information_set
        hands = fct_remaining_hands(info_set.private)

        if node._is_terminal():
            # evaluation at terminal node
            histo = info_set.histo
            L = len(histo)
            if self.opponent_hand is not None:
                if histo[L-2] == 'check' and histo[L-1] == 'check':
                    res = results[info_set.private + self.opponent_hand]
                    return res
                elif histo[L-1] == 'call':
                    res = results[info_set.private + self.opponent_hand] * 2
                    return res
                elif histo[L-1] == 'fold':  # when a starts, a is the one folding
                    res = -1.
                    return res
            else:
                return 'Opponent hand not defined'

        elif node._is_chance():
            # 1st step conducted because history is empty at this point
            next_turn = 'a'
            info_set.next_turn = next_turn
            return self._kuhn_crm_utility_recursive(node, p_a, p_b)

        else:
            node._define_children()
            next_turn = info_set.next_turn
            private_a = info_set.private
            (cfr_p, p) = (p_b, p_a) if next_turn == 'a' else (p_a, p_b)  # ???
            actions = copy.deepcopy(info_set.actions)
            value = 0.
            next_node_utility = {}
            for private_b in hands:
                self.opponent_hand = private_b
                value = 0.
                for act in actions:
                    proba = copy.deepcopy(info_set.proba)
                    next_p_a = p_a * (proba[private_a][act] if next_turn == 'a' else 1.)
                    next_p_b = p_b * (proba[private_b][act] if next_turn == 'b' else 1.)
                    next_node = Node(info_set.child[act])
                    next_node_utility[act] = self._kuhn_crm_utility_recursive(next_node, next_p_a, next_p_b)
                    value += proba[private_a][act] * next_node_utility[act]
                for act in actions:
                    sign = 1 if next_turn == 'a' else -1
                    regret = sign * cfr_p * (next_node_utility[act] - value)
                    self._cumulative_regret(private_b, act, regret)

            if next_turn == 'a':
                dic_sum_regrets = {act: 0. for act in actions}
                for act in actions:
                    for private_b in hands:
                        dic_sum_regrets[act] += self.cumulative_regret[private_b][act]
                sum_regrets = sum(x for x in dic_sum_regrets.values() if x > 0)

                for act in actions:
                    info_set.proba[private_a][act] = \
                        max(dic_sum_regrets[act], 0.)/sum_regrets if sum_regrets > 0 else 1./len(actions)
            following_turn = fct_next_turn(next_turn)
            info_set.next_turn = following_turn

            return value
