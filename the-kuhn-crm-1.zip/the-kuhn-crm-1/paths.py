path_the = "/Users/HayatGabriel/Desktop/KUHN_THE/THE/"
path_old = ""