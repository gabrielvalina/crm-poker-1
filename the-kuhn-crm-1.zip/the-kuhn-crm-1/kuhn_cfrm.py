from cfrm_general import *
import time
import pickle
from paths import *

path = path_the

list_proba = [{'J': {'check': .5, 'bet': .5, 'fold': .5, 'call': .5},
               'Q': {'check': .5, 'bet': .5, 'fold': .5, 'call': .5},
               'K': {'check': .5, 'bet': .5, 'fold': .5, 'call': .5}}]

n_iter = 1000

start = time.time()

for i in range(n_iter):
    for private_a in all_hands:
        for private_b in fct_opponent_hand(private_a):
            # INITIALISATION
            next_turn = 'chance'
            p_a = .5
            p_b = .5
            histo = []
            L = len(list_proba)
            bool = False

            proba = copy.deepcopy(list_proba[L-1])
            actions = define_actions(histo, next_turn)
            info_set = InformationSet(histo, private_a, [], proba, next_turn, actions)
            node = Node(info_set)
            CRMK = CounterfactualRegretMinimizationKuhn(node)
            crm = CRMK._kuhn_crm_utility_recursive(node, p_a, p_b)
            list_proba.append(info_set.proba)

end = time.time()

print(list_proba[len(list_proba)-1])

pickle.dump(list_proba, open(path + "strategy_kuhn_cfr.txt", "wb"))

print(end-start)




