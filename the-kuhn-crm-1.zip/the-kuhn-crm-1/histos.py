from paths import *
import pickle
import random
import time
import numpy as np
import matplotlib as mplt
mplt.use('tkagg')
import matplotlib.pyplot as plt
plt.interactive(False)

start = time.time()

path = path_the
hand_p = pickle.load(open(path + "hand_proba.p", "rb"))
hand_strength = pickle.load(open(path + "hand_strength.p", "rb"))
hand_strength_plt = {key1: {int(key2): hand_strength[key1][key2]
                            for key2 in hand_strength[key1].keys()}
                     for key1 in hand_strength.keys()}
emd_d = pickle.load(open(path + "emd.p", "rb"))

end = time.time()
print('EMD dictionary loaded in ' + str(end - start) + 'sec')  # 0.8sec on average


####################
# Single histogram #
####################

key = random.choice(hand_strength_plt.keys())
ref_p = str(hand_p[key])
d_plot = hand_strength_plt[key]
plt.bar([x - 10 for x in d_plot.keys()], [float(y)/float(sum(d_plot.values()))
                                           for y in d_plot.values()],
        color='b', alpha=0.5, align='edge', width=10, label=key + ', P=' + ref_p)
plt.title(key)
plt.xlabel("Hand Strength")
plt.xticks(np.arange(0, 110, 10))
plt.ylabel("Probability")
plt.legend(loc='upper right')
plt.savefig(path + key + '-hand-strength.png')
plt.show()
plt.close()


########################
# Histogram comparison #
########################

key1 = random.choice(hand_strength_plt.keys())
key2 = random.choice(hand_strength_plt.keys())
ref_emd = emd_d[key1][key2]
ref_p1 = str(hand_p[key1])
d_plot1 = hand_strength_plt[key1]
ref_p2 = str(hand_p[key2])
d_plot2 = hand_strength_plt[key2]
plt.bar([x - 10 for x in d_plot1.keys()], [float(y)/float(sum(d_plot1.values()))
                                           for y in d_plot1.values()],
        color='b', alpha=0.5, align='edge', width=5, label=key1 + ', P=' + ref_p1)
plt.bar([x - 5 for x in d_plot2.keys()], [float(y)/float(sum(d_plot2.values()))
                                          for y in d_plot2.values()],
        color='r', alpha=0.5, align='edge', width=5, label=key2 + ', P=' + ref_p2)
plt.title(key1 + ' VS. ' + key2 + ', EMD: ' + str(ref_emd))
plt.xlabel("Hand Strength")
plt.xticks(np.arange(0, 110, 10))
plt.ylabel("Probability")
plt.legend(loc='upper right')
plt.savefig(path + key1 + 'vs' + key2 + '-hand-strengths.png')
plt.show()
