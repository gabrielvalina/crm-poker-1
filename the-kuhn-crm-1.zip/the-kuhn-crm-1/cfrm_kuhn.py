import random
from cfrm_general import *
from kuhn_functions import *


#######################
# CFRM for Kuhn poker #
#######################

p = .5

pChance = 1./6.
max_length = 3

N = 1  # number of iterations

proba_init = {"J": {"check": 1., "bet": 0., "fold": 1.},
              "Q": {"check": .5, "bet": .5, "fold": .5},
              "K": {"check": 0., "bet": 1., "fold": 0.}}
proba_total = {0: proba_init}
proba = proba_init  # this data will be upgraded


for i in range(N):

    # initialisation (chance node)
    histo = []
    ref = kuhn_deck.keys()
    cA = random.choice(ref)  # player A's card
    vA = kuhn_deck[cA]
    ref.remove(cA)
    cB = random.choice(ref)
    vB = kuhn_deck[cB]
    pot = 2
    pA = 1.
    pB = 1.
    p_Chance = 1./6
    info_set_A = [InformationSet(histo, cA, [], proba)]
    info_set_B = [InformationSet(histo, cB, [], proba)]

    # player A starts (first decision node)
    list_actions = info_set_A[0].define_actions()
    action_A = info_set_A[0].choose_action(list_actions)
    list_actions.remove(action_A)
    histo.append(action_A)
    info_set_A.append(InformationSet(histo, cA, [], proba))
    pot = update_pot(pot, action_A)
    pA = .5*pA
    # CFR calculus at this node

