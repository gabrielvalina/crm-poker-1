from paths import *
from the_functions import *
import sys
import pickle
import numpy as np
import matplotlib as mplt
mplt.use('tkagg')
import matplotlib.pyplot as plt
plt.interactive(False)
from matplotlib import colors
from matplotlib import cm
from scipy.cluster.hierarchy import dendrogram, linkage, fcluster
import scipy.spatial.distance as ssd


####################
# HANDS CLUSTERING #
####################

path = path_the

emd_d = pickle.load(open(path + "emd.p", "rb"))
ref_h = emd_d.keys()
L = len(ref_h)

# Getting index of each hand
n_to_h = {}
I = 0
for h in ref_h:
    n_to_h[I] = h
    I += 1

for h in emd_d.keys():
    for i in range(L):
        if n_to_h[i] != emd_d[h].keys()[i]:
            sys.exit("Index error")

emd_m = np.zeros(shape=(L, L))
for i in range(L):
    ref_i = n_to_h[i]
    for j in range(L):
        ref_j = n_to_h[j]
        emd_m[i][j] = emd_d[ref_i][ref_j]

dist_m = ssd.squareform(emd_m)
Z = linkage(dist_m, 'ward')


##############
# Dendrogram #
##############


def llf(x):
    return n_to_h[x]


plt.figure(figsize=(25,10))
plt.title('Hierarchical Clustering Dendrogram')
plt.xlabel('Sample index')
plt.ylabel('Earth Mover Distance')
dendrogram(Z, leaf_rotation=60., leaf_label_func=llf, leaf_font_size=8)
fig1 = plt.gcf()
print("Dendrogram ready")
plt.show()
fig1.savefig(path + 'EMD-dendrogram.png')
plt.close()


##############
# Clustering #
##############

max_d = 60
clusters = fcluster(Z, max_d, criterion='distance')
print("Number of clusters: " + str(len(set(clusters))))  # 8 clusters


# Dictionary containing all card associated to each cluster
clusters_d = {clusters[i]: [] for i in range(len(clusters))}
for i in range(L):
    clusters_d[clusters[i]].append(n_to_h[i])

pickle.dump(clusters_d, open(path + "clusters.p", "wb"))


#####################
# Chart of clusters #
#####################

clusters_inv = {e: k for k, l in clusters_d.items() for e in l}
ref_m = np.zeros([13, 13])
for k in clusters_inv.keys():
    if k[0] == k[2]:  # pair
        ref_m[max(card_rank[k[0]]) - 2, max(card_rank[k[0]]) - 2] = clusters_inv[k]
    else:
        if k[1] == k[3]:  # suited
            i = min(max(card_rank[k[0]]), max(card_rank[k[2]])) - 2
            j = max(max(card_rank[k[0]]), max(card_rank[k[2]])) - 2
            ref_m[i, j] = clusters_inv[k]
        else:  # unsuited
            i = max(max(card_rank[k[0]]), max(card_rank[k[2]])) - 2
            j = min(max(card_rank[k[0]]), max(card_rank[k[2]])) - 2
            ref_m[i, j] = clusters_inv[k]


legends = ["2", "3", "4", "5", "6", "7", "8", "9", "T", "J", "Q", "K", "A"]
blues = cm.Blues(np.linspace(0,1, num=50))
mycmap = colors.LinearSegmentedColormap.from_list('my_colormap', blues)

fig, ax = plt.subplots()
im = ax.imshow(ref_m, cmap = mycmap, interpolation="none", vmin=-2, vmax=8)

ax.set_xticks(np.arange(len(legends)))
ax.set_yticks(np.arange(len(legends)))
ax.set_xticklabels(legends)
ax.set_yticklabels(legends)

ax.tick_params(top=True, bottom=False,
                   labeltop=True, labelbottom=False)

plt.setp(ax.get_xticklabels(), ha="right",
         rotation_mode="anchor")
ax.xaxis.set_label_position('top')

ax.set_xlabel('Suited')
ax.set_ylabel('Unsuited')

ax.set_title('Chart of clusters', pad=40)

# Loop over data dimensions and create text annotations.
for i in range(len(legends)):
    for j in range(len(legends)):
        text = ax.text(i, j, str(int(ref_m[j, i])),
                       ha="center", va="center", color="w")

fig.tight_layout()
fig2 = plt.gcf()
print("Clusters chart ready")
plt.show()
fig2.savefig(path + 'clusters-chart.png')
plt.close()

# Dictionary with basic statistics on clusters

hand_p = pickle.load(open(path + "hand_proba.p", "rb"))
clusters_inter = {k: [] for k in clusters_d.keys()}
clusters_p = {}
for k in clusters_d.keys():
    for i in range(len(clusters_d[k])):
        clusters_inter[k].append(hand_p[clusters_d[k][i]])
    m_c = np.mean(clusters_inter[k])
    max_c = max(clusters_inter[k])
    min_c = min(clusters_inter[k])
    std_c = np.std(clusters_inter[k])
    med_c = np.median(clusters_inter[k])
    clusters_p[k] = {'mean': m_c, 'min': min_c, 'max': max_c, 'median': med_c, 'standard deviation': std_c}

print(clusters_p)

pickle.dump(clusters_p, open(path + "clusters_proba.p", "wb"))
