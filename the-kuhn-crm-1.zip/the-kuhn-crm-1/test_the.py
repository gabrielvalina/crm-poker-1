import unittest
from the_functions import *


##############
# UNIT TESTS #
##############


class TestPokerHand(unittest.TestCase):

    def test_straight_flush(self):
        draw = ['6S', 'JS', '4C', '8S', 'TS', '7S', '9S']
        result = draw_value(draw)
        self.assertEqual(result, ("Straight flush", 11, 0, 0, 0, 0))

    def test_four(self):
        draw = ['8S', '8C', '4C', 'TS', '8H', '9S', '8D']
        result = draw_value(draw)
        self.assertEqual(result, ("Four of a kind", 8, 0, 0, 0, 0))

    def test_full_house(self):
        draw = ['4S', '8C', '4C', 'TS', '8H', '9S', '4D']
        result = draw_value(draw)
        self.assertEqual(result, ("Full house", 4, 8, 0, 0, 0))

    def test_flush(self):
        draw = ['7S', '8S', '4S', 'TC', 'QS', '9C', 'JS']
        result = draw_value(draw)
        self.assertEqual(result, ("Flush", 12, 0, 0, 0, 0))

    def test_straight(self):
        draw = ['7S', 'KD', '4C', 'TS', 'QH', '9C', 'JC']
        result = draw_value(draw)
        self.assertEqual(result, ("Straight", 13, 0, 0, 0, 0))

    def test_straight_ace_high(self):
        draw = ['AS', 'KD', '4C', 'TS', 'QH', '9C', 'JC']
        result = draw_value(draw)
        self.assertEqual(result, ("Straight", 14, 0, 0, 0, 0))

    def test_straight_ace_low(self):
        draw = ['4S', 'KD', '3C', 'AS', 'QH', '2C', '5C']
        result = draw_value(draw)
        self.assertEqual(result, ("Straight", 5, 0, 0, 0, 0))

    def test_three(self):
        draw = ['4S', '8C', '4C', 'TS', '7H', '9S', '4D']
        result = draw_value(draw)
        self.assertEqual(result, ("Three of a kind", 4, 10, 0, 0, 0))

    def test_two_pair(self):
        draw = ['4S', '8C', 'TC', 'TS', '8H', '9S', '4D']
        result = draw_value(draw)
        self.assertEqual(result, ("Two pair", 10, 8, 9, 0, 0))

    def test_one_pair(self):
        draw = ['4S', 'QC', 'TC', 'KS', '8H', '9S', '4D']
        result = draw_value(draw)
        self.assertEqual(result, ("One pair", 4, 13, 12, 10, 0))

    def test_high_card(self):
        draw = ['4S', 'QC', 'TC', '2S', '8H', '9S', '3D']
        result = draw_value(draw)
        self.assertEqual(result, ("High card", 12, 10, 9, 8, 4))


class WinningPokerHand(unittest.TestCase):

    def test_winning_hand(self):
        h1 = ['AS', '4D']
        h2 = ['AC', 'KD']
        river = ['QS', 'JS', 'TS', '9S', '5S']
        result = winning_hand(h1, h2, river)
        self.assertEqual(result, "Player 1 wins")
