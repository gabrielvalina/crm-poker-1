from paths import *
import pickle
import collections
import time
from scipy.stats import wasserstein_distance


##########################
# Earth Mover's Distance #
##########################


start = time.time()

hand_p = pickle.load(open(path_the + "hand_proba.p", "rb"))
hand_strength = pickle.load(open(path_the + "hand_strength.p", "rb"))
hand_strength_plt = {key1: {int(key2): hand_strength[key1][key2]
                            for key2 in hand_strength[key1].keys()}
                     for key1 in hand_strength.keys()}
player_hand = hand_strength_plt.keys()


emd_d = {}
remain_deck = player_hand[:]
for h1 in player_hand:
    emd_d[h1] = {}
    hs1 = collections.OrderedDict(sorted(hand_strength_plt[h1].items()))
    bin1 = hs1.values()
    for h2 in player_hand:
        hs2 = collections.OrderedDict(sorted(hand_strength_plt[h2].items()))
        bin2 = hs2.values()
        emd_d[h1][h2] = wasserstein_distance(bin1, bin2)

pickle.dump(emd_d, open(path_the + "emd.p", "wb"))

end = time.time()

print(end - start)  # 6-7 sec
