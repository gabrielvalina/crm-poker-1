from the_functions import *
from paths import *
import pandas as pd
import time
import pickle


#####################################
# HAND STRENGTH (on optimized deck) #
#####################################


m = 1000
n = 1000


start = time.time()

path = path_the
hand_strength = {(h[0]+h[1]): {10: 0, 20: 0, 30: 0, 40: 0, 50: 0,
                                   60: 0, 70: 0, 80: 0, 90: 0, 100: 0}
                     for h in player_deck_red}
hand_p = {(h[0]+h[1]): 0. for h in player_deck_red}
ref_win = 0

strength_ref = {(h[0]+h[1]): {} for h in player_deck_red}
for h1 in player_deck_red:
    ref_p = 0
    for i in range(0, m):
        river = river_draw(deck,h1)
        for j in range(0, n):
            h2 = hand(deck,h1+river)
            ref_win += winning_hand_binary(h1, h2, river)
        strength_ref[(h1[0]+h1[1])][i] = float(ref_win)/float(n)
        ref_p += ref_win
        ref_win = 0
    hand_p[(h1[0]+h1[1])] = float(ref_p)/float(m*n)

strength_ref_df = pd.DataFrame(strength_ref)

for h in hand_strength.keys():
    for i in hand_strength[h].keys():
        ref_series = strength_ref_df.apply(
            lambda x: True if (i - 10 < 100*x[h]) and (100*x[h] <= i) else False, axis=1)
        hand_strength[h][i] = len(ref_series[ref_series == True].index)
    ref_series = strength_ref_df.apply(
        lambda x: True if x[h] == 0 else False, axis=1)
    hand_strength[h][10] += len(ref_series[ref_series == True].index)

pickle.dump(hand_p, open(path + "hand_proba.p", "wb"))
pickle.dump(hand_strength, open(path + "hand_strength.p", "wb"))

end = time.time()

print(end - start)  # 38 hours
