from __future__ import division
import collections
import random

# Poker deck & classification
suits = ["S", "C", "H", "D"]  # Spades, Clubs, Hearts, Diamonds
card_rank = {"T": [10], "J": [11], "Q": [12], "K": [13], "A": [1, 14]}
for i in range(2, 10):
    card_rank[str(i)] = [i]

# Deck of 52 cards used in the game
deck = [figure + suit for figure in card_rank.keys() for suit in suits]

# All possible combinations for one player
player_deck = []
remain = deck[:]
while len(remain) > 0:
    for x in remain:
        for y in remain:
            if y != x:
                player_deck = player_deck + [[x,y]]
        remain.remove(x)

hand_rank = {"High card": 1, "One pair": 2, "Two pair": 3,
             "Three of a kind": 4, "Straight": 5, "Flush": 6,
             "Full house": 7, "Four of a kind": 8, "Straight flush": 9}
hand_rank_inv = {j: i for i, j in hand_rank.items()}


##################
# Winning hand ? #
##################

# Function that determines the rank of one's final hand
# and displays value(s) of highest card(s) given a list
# of seven drawn cards (2 in the hand + 5-card draw)
def draw_value(draw):

    # Determine if straight
    ref_max1 = 0
    ref_max2 = 0
    ref_max3 = 0
    ref_max4 = 0
    ref_max5 = 0
    ref_max_s = 0
    ref_max_f = 0
    refdic = {rank: [] for item in draw for rank in card_rank[item[0]]}
    for item in draw:
        for rank in card_rank[item[0]]:
            refdic[rank].append(item)
    refv = refdic.keys()
    refn = 1
    list_c = []
    for i in range(1, len(refdic.keys())):
        if len(refv) > 0:
            min1 = min(refv)
            ref1 = refdic[min1]
            refv = [x for x in refv if x != min1]
            if len(refv) > 0:
                min2 = min(refv)
                if min2 - min1 == 1:
                    refn += 1
                    ref_max_s = min2
                    for item in ref1:
                        list_c.append(item[1])
                elif refn >= 5:
                    break
                else:
                    refn = 1
                    ref_max_s = 0
                    list_c = []

    # To determine if flush
    reff = [item[1] for item in draw]
    refd = collections.Counter(reff)
    refc = max(refd.values())
    refd_bis = {item: [] for item in refd.values()}
    for i, j in refd.items():
        refd_bis[j].append(i)
    for item in draw:
        if item[1] in refd_bis[refc]:
            ref_max_f = max(ref_max_f, max(card_rank[item[0]]))

    if refn >= 5:
        for item in refdic[ref_max_s]:
            list_c.append(item[1])
        ref_max = 0
        for item in suits:
            ref_max = max(ref_max, list_c.count(item))
        if ref_max >= 5:
            return "Straight flush", ref_max_s, ref_max2, ref_max3, ref_max4, ref_max5
        elif refc >= 5:
            return "Flush", ref_max_f, ref_max2, ref_max3, ref_max4, ref_max5
        else:
            return "Straight", ref_max_s, ref_max2, ref_max3, ref_max4, ref_max5
    elif refc >= 5:
        return "Flush", ref_max_f, ref_max2, ref_max3, ref_max4, ref_max5

    '''
    #Pair(s), Full house, 3 or 4 of a kind ?
    refs = [draw[i][0] for i in range(0, len(draw))]
    refp = 0
    refd2 = collections.Counter(refs)
    for value in refd2.values():
        if value == 2:
            refp += 1
    refd2 = {j: i for i, j in refd2.items()}
    max1 = max(refd2.keys())
    many1 = refd2[max1]
    if many1 != []:
        ref_max1 = max([card_rank[item] for item in many1])
    if max1 == 2:
        if refp > 1:
            return "Two pair", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5
        else:
            return "One pair", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5
    elif max1 == 3:
        if refp >= 1:
            return "Full house", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5
        else:
            return "Three of a kind", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5
    elif max1 == 4:
            return "Four of a kind", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5
    ref_max1 = max([card_rank[item[0]] for item in draw])
    return "High card", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5
    '''

    # Pair(s), Full house, 3 or 4 of a kind ?
    ref_d = {max(card_rank[item[0]]): [] for item in draw}
    for item in draw:
        ref_d[max(card_rank[item[0]])].append(item[1])
    for key in ref_d.keys():
        ref_d[key] = len(ref_d[key])
    ref_inv = {j: [] for j in ref_d.values()}
    for i, j in ref_d.items():
        ref_inv[j].append(i)

        # Four of a kind ?
    if max(ref_inv.keys()) == 4:
        ref_max1 = max(ref_inv[4])
        return "Four of a kind", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5

        # Full house or three of a kind ?
    elif max(ref_inv.keys()) == 3:
        ref_max1 = max(ref_inv[3])
        if len(ref_inv[3]) > 1:
            ref_max2 = min(ref_inv[3])
            return "Full house", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5
        elif 2 in ref_inv.keys():
            ref_max2 = max(ref_inv[2])
            return "Full house", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5
        ref_max2 = max([item for key in ref_inv.keys() for item in ref_inv[key]
                        if item not in ref_inv[3]])
        return "Three of a kind", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5

        # Two pair or one pair ?
    elif max(ref_inv.keys()) == 2:
        ref_max1 = max(ref_inv[2])
        if len(ref_inv[2]) > 1:
            ref_max2 = max([item for item in ref_inv[2] if item != ref_max1])
            ref_max3 = max([item for key in ref_inv.keys() for item in ref_inv[key]
                            if (item != ref_max1) and (item != ref_max2)])
            return "Two pair", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5
        ref_max2 = max([item for key in ref_inv.keys() for item in ref_inv[key]
                        if item not in ref_inv[2]])
        ref_max3 = max([item for key in ref_inv.keys() for item in ref_inv[key]
                        if (item not in ref_inv[2]) and (item != ref_max2)])
        ref_max4 = max([item for key in ref_inv.keys() for item in ref_inv[key]
                        if (item not in ref_inv[2]) and (item != ref_max2) and (item != ref_max3)])
        return "One pair", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5

    ref_max1 = max(ref_d.keys())
    ref_max2 = max([item for item in ref_d.keys() if item != ref_max1])
    ref_max3 = max([item for item in ref_d.keys() if item not in [ref_max1, ref_max2]])
    ref_max4 = max([item for item in ref_d.keys() if item not in [ref_max1, ref_max2, ref_max3]])
    ref_max5 = max([item for item in ref_d.keys() if item not in [ref_max1, ref_max2, ref_max3, ref_max4]])
    return "High card", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5


def winning_hand(h1,h2,river):
    p1 = h1 + river
    p2 = h2 + river
    if hand_rank[draw_value(p1)[0]] > hand_rank[draw_value(p2)[0]]:
        return "Player 1 wins"
    elif hand_rank[draw_value(p1)[0]] < hand_rank[draw_value(p2)[0]]:
        return "Player 2 wins"
    else:
        for i in range(1, 6):
            if draw_value(p1)[i] == 0:
                return "Draw"
            if draw_value(p1)[i] > draw_value(p2)[i]:
                return "Player 1 wins"
            elif draw_value(p1)[i] < draw_value(p2)[i]:
                return "Player 2 wins"
        return "Draw"


################
# Optimization #
################

# Optimizing draw_value function
def draw_value_opt(draw):
    ref_max1 = 0
    ref_max2 = 0
    ref_max3 = 0
    ref_max4 = 0
    ref_max5 = 0

    # Dictionary of value of draw cards associated to colors present in draw
    ref_d = {rank: [] for item in draw for rank in card_rank[item[0]]}
    for item in draw:
        for rank in card_rank[item[0]]:
            ref_d[rank].append(item[1])

    # Straight or Straight Flush ?
    ref_list = ref_d.keys()
    ref_list.sort()
    ref_n = 0
    ref_set = {}
    for i in range(0, 3):
        if i+4 <= len(ref_list)-1:
            if ref_list[i+4] == ref_list[i] + 4:
                ref_max1 = ref_list[i+4]
                j = i+5
                while j <= len(ref_list)-1:
                    if ref_list[j] == ref_list[j-1] + 1:
                        ref_max1 = max(ref_max1, ref_list[j])
                        j += 1
                    else:
                        break
                ref_set = set(ref_d[ref_list[i]])
                ref_n = ref_max1 - i
                for j in range(1, 5):
                    ref_set.intersection_update(set(ref_d[ref_list[i+j]]))

    ref_d.pop(1, None)

    # Flush ?
    ref_c = 0
    ref_maxc = 0
    for item in suits:
        ref_c = 0
        ref_maxc = 0
        for key in ref_d.keys():
            if item in ref_d[key]:
                ref_c += 1
                ref_maxc = max(ref_maxc, int(key))
        if ref_c >= 5:
            break

    if ref_n >= 5:
        if len(ref_set) > 0:
            return "Straight flush", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5
        elif ref_c >= 5:
            return "Flush", ref_maxc, ref_max2, ref_max3, ref_max4, ref_max5
        else:
            return "Straight", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5
    elif ref_c >= 5:
        return "Flush", ref_maxc, ref_max2, ref_max3, ref_max4, ref_max5

    # Pair(s), Full house, 3 or 4 of a kind ?
    for key in ref_d.keys():
        ref_d[key] = len(ref_d[key])
    ref_inv = {j: [] for j in ref_d.values()}
    for i, j in ref_d.items():
        ref_inv[j].append(i)

        # Four of a kind ?
    if max(ref_inv.keys()) == 4:
        ref_max1 = max(ref_inv[4])
        return "Four of a kind", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5

        # Full house or three of a kind ?
    elif max(ref_inv.keys()) == 3:
        ref_max1 = max(ref_inv[3])
        if len(ref_inv[3]) > 1:
            ref_max2 = min(ref_inv[3])
            return "Full house", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5
        elif 2 in ref_inv.keys():
            ref_max2 = max(ref_inv[2])
            return "Full house", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5
        ref_max2 = max([item for key in ref_inv.keys() for item in ref_inv[key]
                        if item not in ref_inv[3]])
        return "Three of a kind", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5

        # Two pair or one pair ?
    elif max(ref_inv.keys()) == 2:
        ref_max1 = max(ref_inv[2])
        if len(ref_inv[2]) > 1:
            ref_max2 = max([item for item in ref_inv[2] if item != ref_max1])
            ref_max3 = max([item for key in ref_inv.keys() for item in ref_inv[key]
                            if (item != ref_max1) and (item != ref_max2)])
            return "Two pair", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5
        ref_max2 = max([item for key in ref_inv.keys() for item in ref_inv[key]
                        if item not in ref_inv[2]])
        ref_max3 = max([item for key in ref_inv.keys() for item in ref_inv[key]
                        if (item not in ref_inv[2]) and (item != ref_max2)])
        ref_max4 = max([item for key in ref_inv.keys() for item in ref_inv[key]
                        if (item not in ref_inv[2]) and (item != ref_max2) and (item != ref_max3)])
        return "One pair", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5

    ref_max1 = max(ref_d.keys())
    ref_max2 = max([item for item in ref_d.keys() if item != ref_max1])
    ref_max3 = max([item for item in ref_d.keys() if item not in [ref_max1, ref_max2]])
    ref_max4 = max([item for item in ref_d.keys() if item not in [ref_max1, ref_max2, ref_max3]])
    ref_max5 = max([item for item in ref_d.keys() if item not in [ref_max1, ref_max2, ref_max3, ref_max4]])
    return "High card", ref_max1, ref_max2, ref_max3, ref_max4, ref_max5


def winning_hand_opt(h1,h2,river):
    p1 = h1 + river
    p2 = h2 + river
    if hand_rank[draw_value_opt(p1)[0]] > hand_rank[draw_value_opt(p2)[0]]:
        return "Player 1 wins"
    elif hand_rank[draw_value_opt(p1)[0]] < hand_rank[draw_value_opt(p2)[0]]:
        return "Player 2 wins"
    else:
        for i in range(1, 6):
            if draw_value_opt(p1)[i] == 0:
                return "Draw"
            if draw_value_opt(p1)[i] > draw_value_opt(p2)[i]:
                return "Player 1 wins"
            elif draw_value_opt(p1)[i] < draw_value_opt(p2)[i]:
                return "Player 2 wins"
        return "Draw"


def winning_hand_binary(h1,h2,river):
    p1 = h1 + river
    p2 = h2 + river
    if hand_rank[draw_value_opt(p1)[0]] > hand_rank[draw_value_opt(p2)[0]]:
        return 1
    elif hand_rank[draw_value_opt(p1)[0]] < hand_rank[draw_value_opt(p2)[0]]:
        return 0
    else:
        for i in range(1, 6):
            if draw_value_opt(p1)[i] == 0:
                return 0
            if draw_value_opt(p1)[i] > draw_value_opt(p2)[i]:
                return 1
            elif draw_value_opt(p1)[i] < draw_value_opt(p2)[i]:
                return 0
        return 0


################
# Random draws #
################

# Player's hand given the cards already delt
def hand(d, c):
    d_upd = d[:]
    for item in c:
        d_upd.remove(item)
    c0 = random.choice(d_upd)
    d_upd.remove(c0)
    c1 = random.choice(d_upd)
    return [c0,c1]


# 5-card draw given card already delt
def river_draw(d, c):
    d_upd = d[:]
    for item in c:
        d_upd.remove(item)
    river = []
    for i in range(0, 5):
        c0 = random.choice(d_upd)
        river.append(c0)
        d_upd.remove(c0)
    return river


################################
# Reducing the number of hands #
################################

# We can reduce the number of studied hands by grouping the colors
# We can keep only the spades and the hearts for example

deck_red = [figure + suit for figure in card_rank.keys() for suit in ["S", "H"]]
# 26 cards

player_deck_ref = []
for l in player_deck:
    i = l[0].replace("C", "S")
    i = i.replace("D", "H")
    j = l[1].replace("C", "S")
    j = j.replace("D", "H")
    if i != j:
        player_deck_ref.append([i, j])
player_deck_red = []
for e in player_deck_ref:
    ref = e[:]
    ref.reverse()
    if (e not in player_deck_red) and (ref not in player_deck_red):
        player_deck_red.append(e)
# 325 hands

# AS 4S statistically equivalent to AH 4H
# AS 4H statistically equivalent to AH 4S
for l in player_deck_red:
    # Case suited
    if l[0][1] == l[1][1]:
        e0 = l[0].replace("S", "H")
        e1 = l[1].replace("S", "H")
        e = [e0, e1]
        if e == l:
            e0 = l[0].replace("H", "S")
            e1 = l[1].replace("H", "S")
            e = [e0, e1]
        if e in player_deck_red:
            player_deck_red.remove(e)
    else:
        e0 = l[0].replace("S", "H")
        e1 = l[1].replace("H", "S")
        e = [e0, e1]
        if e == l:
            e0 = l[0].replace("H", "S")
            e1 = l[1].replace("S", "H")
            e = [e0, e1]
        if e in player_deck_red:
            player_deck_red.remove(e)

# 169 remaining hands
