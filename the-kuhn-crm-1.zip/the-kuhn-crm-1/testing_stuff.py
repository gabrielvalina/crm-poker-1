
import pickle
from paths import *


#L = pickle.load(open(path_the + "strategy_a.txt", "rb"))

d = {}

d[4] += 1

print(d)